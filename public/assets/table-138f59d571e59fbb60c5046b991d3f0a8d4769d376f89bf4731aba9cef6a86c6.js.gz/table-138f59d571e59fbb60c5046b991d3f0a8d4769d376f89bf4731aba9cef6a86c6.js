$(document).on('ready turbolinks:load', function() {
  FixedMidashi.create();
});
